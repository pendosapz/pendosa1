exports.isDomainId = value => /^[\w-_]+$/.test(value)
