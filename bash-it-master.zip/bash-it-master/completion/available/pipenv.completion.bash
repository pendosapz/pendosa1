[[ -x "$(which pipenv)" ]] && eval "$(pipenv --completion)"
