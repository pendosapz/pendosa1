_log_error 'Bash completion for "drush" is now deprecated, as it used code with incompatible license.
Please disable this completion and use the instructions from "drush" developers instead.'
