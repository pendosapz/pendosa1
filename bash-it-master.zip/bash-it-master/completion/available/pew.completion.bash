[[ -x "$(which pew)" ]] && source "$(pew shell_config)"
