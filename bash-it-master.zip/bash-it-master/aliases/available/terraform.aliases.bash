# Aliases for Terraform and Terragrunt

cite 'about-alias'
about-alias 'Terraform abbreviations'

alias tf='terraform'
alias tfv='terraform validate'
alias tfp='terraform plan'
alias tfa='terraform apply'
alias tfd='terraform destory'
