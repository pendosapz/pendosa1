.. _troubleshooting:

Troubleshooting Guide
=====================

Table of Contents
-----------------

* `I'm stuck in the LightDM login screen after setting up bash-it. <im-stuck-in-the-lightdm-login-screen-after-setting-up-bash-it>`_

I'm stuck in the LightDM login screen after setting up bash-it
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

**Possible issue**\ : `#672 <https://github.com/Bash-it/bash-it/issues/672>`_

**Solution**\ : Check `this comment <https://github.com/Bash-it/bash-it/issues/672#issuecomment-257870653>`_ for detailed information about the cause and solution for this issue.
